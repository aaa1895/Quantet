import os
import OpenDartReader
import pandas as pd
import time


def convert_str_to_float(value):
    if type(value) == float:
        return value
    elif value == '-':
        return 0
    else:
        return float(value.replace(',', ''))


def download_financial_statements(api_key, save_path, csv_path, year_start, year_end):
    # OpenDartReader 객체 생성
    dart = OpenDartReader(api_key)

    # 종목 코드가 포함된 CSV 파일 불러오기
    stock_list = pd.read_csv(csv_path, encoding='euc-kr')

    # 재무제표 다운로드
    for idx, row in stock_list.iterrows():
        code = row['종목코드']
        name = row['종목명']

        # 회사별 재무제표 다운로드
        for year in range(year_start, year_end + 1):
            try:
                # 재무제표 다운로드
                financial_statements = dart.finstate_all(code, year)

                # 파일 경로 생성
                file_path = os.path.join(save_path, f'{name}_{year}_financial_statements.csv')

                # CSV 파일로 저장
                financial_statements.to_csv(file_path, index=False, encoding='utf-8-sig')

                print(f'{name} ({year}) 재무제표 다운로드 완료')
            except Exception as e:
                print(f'{name} ({year}) 재무제표 다운로드 실패:', e)

            time.sleep(0.5)  # API 호출 제한을 준수하기 위해 0.5초 대기


# API 키
#api_key = '00e95a40173bc8b4c84320499108fb98d94039ad'
#api_key='5ae5fda3975b556882908f8828fe8aa7a2b43c9e'
api_key = '	e27f14326b68deac2d09a57ddfff58998d8b2bad'
# 재무제표를 저장할 디렉토리 경로
save_path = r"C:\Dart"

# 다운로드할 데이터 범위 (연도)
year_start = 2015
year_end = 2024

# 종목 코드가 포함된 CSV 파일 경로
csv_path = r"C:\Dart\data\data_3050_20240402.csv"

# 디렉토리 생성
os.makedirs(save_path, exist_ok=True)

# 재무제표 다운로드
download_financial_statements(api_key, save_path, csv_path, year_start, year_end)

